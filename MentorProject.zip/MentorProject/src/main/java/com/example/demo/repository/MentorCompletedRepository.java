package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.MentorCompleted;
import com.example.demo.model.UserD;

@Repository
public interface MentorCompletedRepository extends JpaRepository<MentorCompleted, Integer>{

	List<MentorCompleted> findByUserlogname(UserD ud);

}
