package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompleted;
import com.example.demo.model.MentorCurrent;
import com.example.demo.model.Role;
import com.example.demo.model.UserD;
import com.example.demo.repository.MentorCompletedRepository;
import com.example.demo.repository.MentorCurrentRepository;
import com.example.demo.repository.MentorRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserDetailRepository;

@Service
public class MentorService {
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private UserDetailRepository userDetailRepository;
	
	@Autowired
	private MentorRepository mentorRepository;
	
	@Autowired
	private MentorCompletedRepository mentorCompletedRepository;
	
	@Autowired
	private MentorCurrentRepository mentorCurrentRepository;

	public Iterable<Role> showallroles() {
		return roleRepository.findAll();
	}

	public Role findrole(int rid) {
		return roleRepository.findById(rid);
	}
	public String addmentor(UserD u) {

		int uid = 2;
		Role r = roleRepository.findById(uid);
		u.setRole(r);

		userDetailRepository.save(u);
		return "Log in Mentor Added";
	}
	public List<UserD> findAllMentor() {
		return userDetailRepository.findAll();
	}

	public UserD findMentor(String mentorname) {
		return userDetailRepository.findByUserlogname(mentorname);
	}

	public String savementordetails(Mentor mr) {
		mentorRepository.save(mr);
		return "Mentor SignUp Saved" ;
	}

	public List<Mentor> showmentor() {
		
		return mentorRepository.findAll();
	}

	public List<Mentor> showmentorbyname(String tutor) {

		return mentorRepository.findByMentorname(tutor);
	}

	public List<MentorCompleted> completedcourse() {
		
		return mentorCompletedRepository.findAll();
	}

	public List<MentorCompleted> completedcoursename(String mentorname) {
		UserD ud = userDetailRepository.findByUserlogname(mentorname);
		return mentorCompletedRepository.findByUserlogname(ud);
	}

	public List<MentorCurrent> currentcourse() {
		
		return mentorCurrentRepository.findAll();
	}

	public List<MentorCurrent> currentcoursename(String mentorname) {
		UserD ud = userDetailRepository.findByUserlogname(mentorname);
		return mentorCurrentRepository.findByUserlogname(ud);
	}

	public List<Mentor> showtechnology(String tech) {
	
		return mentorRepository.findByTechnology(tech);
	}

	
}
