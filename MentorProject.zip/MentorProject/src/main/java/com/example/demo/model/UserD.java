package com.example.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class UserD {

	@Id
	private String userlogname;
	private String userpassword;
	private String userlogemail;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="role")
	private Role role;
	

	public String getUserlogname() {
		return userlogname;
	}

	public void setUserlogname(String userlogname) {
		this.userlogname = userlogname;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public String getUserlogemail() {
		return userlogemail;
	}

	public void setUserlogemail(String userlogemail) {
		this.userlogemail = userlogemail;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

}
