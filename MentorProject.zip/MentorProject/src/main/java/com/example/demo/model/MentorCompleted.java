package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class MentorCompleted {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mcid;
	private String technology;
	private String duration;
	private int fees;
	private String compercent;
	
	@ManyToOne()
	@JoinColumn(name="userlogname")
	private UserD userlogname;

	public int getMcid() {
		return mcid;
	}

	public void setMcid(int mcid) {
		this.mcid = mcid;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public String getCompercent() {
		return compercent;
	}

	public void setCompercent(String compercent) {
		this.compercent = compercent;
	}

	public UserD getUserlogname() {
		return userlogname;
	}

	public void setUserlogname(UserD userlogname) {
		this.userlogname = userlogname;
	}
	
}
