package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompleted;
import com.example.demo.model.MentorCurrent;
import com.example.demo.model.Role;
import com.example.demo.model.UserD;
import com.example.demo.service.MentorService;

@Controller
@RequestMapping(path="/mentor")
@CrossOrigin("http://localhost:4200")

public class MentorController {

	@Autowired
	private MentorService mentorService;

	@GetMapping(path="/identity")
	public @ResponseBody Iterable<Role> showall() {
		return mentorService.showallroles();
	}

	@GetMapping(path="/identity/{id}")
	public @ResponseBody Role showRole(@PathVariable("id") int rid) {
		return mentorService.findrole(rid);
	}

	@PostMapping(path="/add")
	public @ResponseBody String addmentor(@RequestBody UserD u) {

		return mentorService.addmentor(u);
	}

	@GetMapping(path="/all")
	public @ResponseBody List<UserD> showMentor() {
		return mentorService.findAllMentor();
	}

	@GetMapping(path="/all/{userlogname}")
	public @ResponseBody UserD showMentorById(@PathVariable("userlogname") String mentorname) {
		return mentorService.findMentor(mentorname);
	}

	@GetMapping(path="/completed/all")
	public @ResponseBody List<MentorCompleted> showcompleted() {
		return mentorService.completedcourse();
	}

	@GetMapping(path="/completed/{userlogname}")
	public @ResponseBody List<MentorCompleted> completedMentor(@PathVariable("userlogname") String mentorname) {
		return mentorService.completedcoursename(mentorname);
	}

	@GetMapping(path="/current/all")
	public @ResponseBody List<MentorCurrent> showCurrent() {
		return mentorService.currentcourse();
	}

	@GetMapping(path="/current/{userlogname}")
	public @ResponseBody List<MentorCurrent> currentmentor(@PathVariable("userlogname") String mentorname) {
		return mentorService.currentcoursename(mentorname);
	}

	@PostMapping(path="/savementor")
	public @ResponseBody String createMentor(@RequestBody Mentor mr) {
		return mentorService.savementordetails(mr);
	}

	@GetMapping(path="/allmentor")
	public @ResponseBody List<Mentor> showsignupmentor() {
		return mentorService.showmentor();
	}

	@GetMapping(path = "/show/{mentorname}")
	public @ResponseBody List<Mentor> showByName(@PathVariable("mentorname") String tutor) {
		return mentorService.showmentorbyname(tutor);
	}
	@GetMapping(path = "/{technology}")
	public @ResponseBody List<Mentor> showtech(@PathVariable("technology") String tech) {
		return mentorService.showtechnology(tech);
	}
}
