package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class MentorCurrent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mid;
	private String technology;
	private String timeduration;
	private int amount;
	private String percent;
	private String remainingpercent;
	
	@ManyToOne()
	@JoinColumn(name="userlogname")
	private UserD userlogname;

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getTimeduration() {
		return timeduration;
	}

	public void setTimeduration(String timeduration) {
		this.timeduration = timeduration;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getPercent() {
		return percent;
	}

	public void setPercent(String percent) {
		this.percent = percent;
	}

	public String getRemainingpercent() {
		return remainingpercent;
	}

	public void setRemainingpercent(String remainingpercent) {
		this.remainingpercent = remainingpercent;
	}

	public UserD getUserlogname() {
		return userlogname;
	}

	public void setUserlogname(UserD userlogname) {
		this.userlogname = userlogname;
	}

	
}
