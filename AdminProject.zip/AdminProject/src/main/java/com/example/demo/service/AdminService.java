package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Mentor;
import com.example.demo.model.Payment;
import com.example.demo.model.Technology;
import com.example.demo.model.UserBlock;
import com.example.demo.model.UserD;
import com.example.demo.model.UserMain;
import com.example.demo.repository.MentorRepository;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.TechnologyRepository;
import com.example.demo.repository.UserBlockRepository;
import com.example.demo.repository.UserDetailRepository;
import com.example.demo.repository.UserMainRepository;

@Service
public class AdminService {
	@Autowired
	private MentorRepository mentorRepository;
	@Autowired
	private PaymentRepository paymentRepository;
	@Autowired
	private TechnologyRepository technologyRepository;
	@Autowired
	private UserMainRepository userMainRepository;
	@Autowired
	private UserDetailRepository userDetailRepository;
	@Autowired
	private UserBlockRepository userBlockRepository;

	public List<Technology> findTechnology() {
		return (List<Technology>) technologyRepository.findAll();

	}

	public List<Payment> findPayment() {
		return (List<Payment>) paymentRepository.findAll();

	}
	

	public List<UserMain> findUser() {
		return (List<UserMain>) userMainRepository.findAll();

	}

	public List<Mentor> findMentor() {
		return (List<Mentor>) mentorRepository.findAll();

	}

	public void savetechnology(Technology t) {
		technologyRepository.save(t);
	}

	@Transactional
	public void userBlock(String username) {
		UserD u = userDetailRepository.findByUserlogname(username);
		UserBlock ub = new UserBlock();
		ub.setUserlogname(u.getUserlogname());
		ub.setUserpassword(u.getUserpassword());
		ub.setUserlogemail(u.getUserlogemail());
		ub.setRole(u.getRole());
		userBlockRepository.save(ub);
		userDetailRepository.deleteByUserlogname(username);

	}

	@Transactional
	public void userUnBlock(String username) {

		UserBlock u = userBlockRepository.findByUserlogname(username);
		UserD ub = new UserD();
		ub.setUserlogname(u.getUserlogname());
		ub.setUserpassword(u.getUserpassword());
		ub.setUserlogemail(u.getUserlogemail());
		ub.setRole(u.getRole());
		userDetailRepository.save(ub);
		userBlockRepository.deleteByUserlogname(username);
	}

	public List<Payment> findPaymentall(String name) {
		
		UserD u = userDetailRepository.findByUserlogname(name);
		return paymentRepository.findByUserlogname(u);
	}

}
