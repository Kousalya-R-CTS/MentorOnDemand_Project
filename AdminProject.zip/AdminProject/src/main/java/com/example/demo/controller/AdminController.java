package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Mentor;
import com.example.demo.model.Payment;
import com.example.demo.model.Technology;
import com.example.demo.model.UserMain;
import com.example.demo.service.AdminService;

@Controller
@RequestMapping(path="/admin")
@CrossOrigin("http://localhost:4200")

public class AdminController {
	@Autowired
	private AdminService adminService;

	@GetMapping(path="/findpayment")
	public @ResponseBody List<Payment> findpayment() {
		return adminService.findPayment();
	}
	@GetMapping(path="/findpayment/{userlogname}")
	public @ResponseBody List<Payment> findpaymentall(@PathVariable("userlogname") String name) {
		return adminService.findPaymentall(name);
	}

	@GetMapping(path="/findadmintechnology")
	public @ResponseBody List<Technology> findtechnology() {
		return adminService.findTechnology();
	}

	@GetMapping(path="/finduser")
	public @ResponseBody List<UserMain> finduser() {
		return adminService.findUser();
	}

	@GetMapping(path="/findmentor")
	public @ResponseBody List<Mentor> findmentor() {
		return adminService.findMentor();
	}

	@GetMapping(path="/savetechnology/{technology}/{duration}")
	public @ResponseBody String savetechnology(@PathVariable String technology, @PathVariable String duration) {
		Technology t = new Technology();
		t.setTechnology(technology);
		t.setDuration(duration);

		adminService.savetechnology(t);
		return "stored";
	}

	@GetMapping(path="/userblock/{userlogname}")
	public @ResponseBody String userblock(@PathVariable String userlogname) {

		adminService.userBlock(userlogname);
		return "deleted";
	}

	@GetMapping(path="/userunblock/{userlogname}")
	public @ResponseBody String userunblock(@PathVariable String userlogname) {

		adminService.userUnBlock(userlogname);
		return "added";
	}

}
