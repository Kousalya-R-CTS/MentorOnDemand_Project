package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Payment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private long amount;
	private String technology;
	private String duration;
	private long receiptno;
	private String paytype;
	private String status;
	@ManyToOne()
	@JoinColumn(name="userlogname")
	private UserD userlogname;
	
	public UserD getUserlogname() {
		return userlogname;
	}
	public void setUserlogname(UserD userlogname) {
		this.userlogname = userlogname;
	}
	public long getReceiptno() {
		return receiptno;
	}
	public void setReceiptno(long receiptno) {
		this.receiptno = receiptno;
	}
	public String getPaytype() {
		return paytype;
	}
	public void setPaytype(String paytype) {
		this.paytype = paytype;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}

}
