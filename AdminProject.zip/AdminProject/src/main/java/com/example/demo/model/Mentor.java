package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mentor {
	@Id
	private String mentorname;
	private String technology;
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	private String duration;
	private String mentormail;
	private String mentorpassword;
	private String confirmpassword;
	public String getMentorname() {
		return mentorname;
	}
	public void setMentorname(String mentorname) {
		this.mentorname = mentorname;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getMentormail() {
		return mentormail;
	}
	public void setMentormail(String mentormail) {
		this.mentormail = mentormail;
	}
	public String getMentorpassword() {
		return mentorpassword;
	}
	public void setMentorpassword(String mentorpassword) {
		this.mentorpassword = mentorpassword;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	
}
