package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.UserBlock;

@Repository
public interface UserBlockRepository extends CrudRepository<UserBlock, String>{

	UserBlock findByUserlogname(String userlogname);

	void deleteByUserlogname(String userlogname);

}
