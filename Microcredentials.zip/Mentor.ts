export class Mentor {
    mentorname:string;
    confirmpassword:string;
    duration:string;
    mentormail:string;
    mentorpassword:string;
    technology:string;
}