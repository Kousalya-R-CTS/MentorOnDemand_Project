export class Role{
    id:number;
    role:string;
}