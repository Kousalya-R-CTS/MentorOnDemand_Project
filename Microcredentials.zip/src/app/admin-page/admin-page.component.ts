import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {
search: string;
pay: string;
dispadm = false;
disp1 = false;
disp2 = false;
disp3 = false;
disp4 = false;
username:string;
adminhome = [];
users = ['Mala', 'Kavitha', 'Shruthi', 'Lakshmi', 'Pooja'];
mentors = ['Kousalya R', 'Geetha D', 'Revathi R', 'Priya R', 'Shruthi E'];
courses = ['Java', '.Net', 'Angular', 'Bootstrap'];

  constructor(private service: CourseService,private router:ActivatedRoute) { }

  ngOnInit() {
    this.username=this.router.snapshot.paramMap.get('userlogname');
  }
  validate() {
    if (this.search === 'java' || this.search === '.net' || this.search === 'angular' || this.search === 'bootstrap') {
    this.pay = this.search;
    this.dispadm = true;
    this.disp1 = false;
    this.disp2 = false;
    this.disp3 = false;
    this.disp4 = false;
    this.search = '';
    this.service.getorder().subscribe(data => this.adminhome = data as string[]);
    } else {
      this.search = '';
    }
  }
  edit() {
    this.dispadm = false;
    this.disp1 = true;
    this.disp2 = false;
    this.disp3 = false;
    this.disp4 = false;
    this.service.getorder().subscribe(data => this.adminhome = data as string[]);
  }
  payment() {
    this.dispadm = false;
    this.disp1 = false;
    this.disp2 = true;
    this.disp3 = false;
    this.disp4 = false;
    // this.service.findpayment().subscribe(value => this.adminhome = value as string[]);
  }
  uswap() {
    this.dispadm = false;
    this.disp1 = false;
    this.disp2 = false;
    this.disp3 = true;
    this.disp4 = false;
    this.service.getorder().subscribe(data => this.adminhome = data as string[]);
  }
  mswap() {
    this.dispadm = false;
    this.disp1 = false;
    this.disp2 = false;
    this.disp3 = false;
    this.disp4 = true;
    this.service.getorder().subscribe(data => this.adminhome = data as string[]);
  }
}
