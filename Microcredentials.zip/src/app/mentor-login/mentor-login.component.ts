import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CourseService } from '../course.service';
import { Mentor } from 'Mentor';
@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {
  mentor:Mentor = new Mentor();

  mname:string;
  mentorname:string;
  mpass1:string;
  mentorpassword:string;
  confirmpassword:string;
  duration:string;
  mentormail: string;
  technology:string;
  constructor(private route:Router, private service:CourseService) { }

  ngOnInit() {
    
  }
mentorin() {

  if(this.mname ==null) {
    alert("Enter valid username");
    return false;
    }
    if(this.mpass1 ==null) {
     alert("Enter valid password");
     return false;
    }
    if(this.mpass1.length < 8) {
      alert("Enter password with a length of 8 characters");
      return false;
    }
    if(this.mname.length != null && this.mpass1.length >=8) {
      this.route.navigate(['/mentor-page']);
      return true;
    }

}
addmentordetails() {
  this.mentor.mentorname = this.mentorname;
  this.mentor.mentormail = this.mentormail;
  this.mentor.mentorpassword = this.mentorpassword;
  this.mentor.confirmpassword = this.confirmpassword;
  this.mentor.duration = this.duration;
  this.mentor.technology = this.technology;
  if(this.mentorname == null) {
    alert("Enter valid username");
    return false;
    }
    if(this.mentormail == null) {
      alert("Enter valid username");
      return false;
      }
    if(this.mentorpassword == null) {
     alert("Enter valid password");
     return false;
    }
    if(this.technology == null) {
      alert("Enter valid technology for mentor");
      return false;
     }
    if(this.mentorpassword.length < 8) {
      alert("Enter password with a length of 8 characters");
      return false;
    }
    if(this.mentorpassword != this.confirmpassword) {
      alert("Enter the both the password correctly");
      return false;
    }
    
    if((this.mentormail.length != null) && (this.mentorname.length != null) && 
    (this.mentorpassword.length >= 8) && (this.technology.length != null) && (this.mentorpassword == this.confirmpassword)) {
      this.service.createMentor(this.mentor)
      .subscribe(data => console.log(data), error => console.log(error));
      this.route.navigate(['admin-login']);
      return true;
    }
}
}
