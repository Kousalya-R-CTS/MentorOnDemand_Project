import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class CourseService {
  url = '/assets/home.json';
  url1 = '/assets/office.json';
  baseUrl = 'http://localhost:8080/api';
  constructor(private http: HttpClient) { }
  // getdata() {
  //   return this.http.get(this.url);
  // }
  getorder() {
    return this.http.get(this.url1);
  }
  searchtech(aCourse:string): Observable<any> {
    return this.http.get(`${this.baseUrl}/userproject/user/search/${aCourse}`);
  }
  getallcourse() {
    return this.http.get(`${this.baseUrl}/userproject/user/allcourses`);
  }
  getusercurrent(userlogname:string) {
    return this.http.get(`${this.baseUrl}/userproject/user/current/${userlogname}`);
  }
  getusercomplete(userlogname:string) {
    return this.http.get(`${this.baseUrl}/userproject/user/completed/${userlogname}`);
  }
  createUser(userMain: object): Observable<object> {  
    return this.http.post(`${this.baseUrl}/userproject/user/saveuser`, userMain);  
  } 
  createUserRegister(userregister:object):Observable<object> {
    return this.http.post(`${this.baseUrl}/userproject/user/add`,userregister);
  }
  createMentor(mentor: object): Observable<object> {
    return this.http.post(`${this.baseUrl}/mentorproject/mentor/savementor`,mentor);
  }
  findUser(userlogname:string):Observable<any> {
return this.http.get(`${this.baseUrl}/userproject/user/all/${userlogname}`);
  }
  // findpayment() {

  // }
  getmentorcurrent(userlogname:string):Observable<any> {
    return this.http.get(`${this.baseUrl}/mentorproject/mentor/current/${userlogname}`);
  }
  getmentorcomplete(userlogname:string):Observable<any> {
    return this.http.get(`${this.baseUrl}/mentorproject/mentor/completed/${userlogname}`);
  }
}
