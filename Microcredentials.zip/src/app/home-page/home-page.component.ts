import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
aCourse: string;
private homeview = [];
dispview = false;
  constructor(private service: CourseService) { }

  ngOnInit() {
  }
display() {
if ((this.aCourse === 'java' || this.aCourse === '.net' || this.aCourse === 'angular' || this.aCourse === 'bootstrap')) {
  this.dispview = true;
  
  this.service.searchtech(this.aCourse).subscribe( data => this.homeview = data as string[]);
  this.aCourse = '';
} else {
  this.aCourse = '';
}
}
}
