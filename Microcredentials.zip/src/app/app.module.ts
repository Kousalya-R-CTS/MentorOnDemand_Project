import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { UserPageComponent } from './user-page/user-page.component';
import { MentorPageComponent } from './mentor-page/mentor-page.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { CourseService } from './course.service';
@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    UserLoginComponent,
    MentorLoginComponent,
    AdminLoginComponent,
    UserPageComponent,
    MentorPageComponent,
    AdminPageComponent,
    MentorProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
