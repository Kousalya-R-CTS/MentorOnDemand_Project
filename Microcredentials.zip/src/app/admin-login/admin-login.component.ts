import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CourseService } from '../course.service';
import { UserD } from 'UserD';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  userlogname: string ;
  userpassword:string ;
	userlogemail:string ;
invalidLogin :boolean=false;
 userlogin:UserD=new UserD();
 private error=false;
  constructor(private router: Router,private service:CourseService) { }

  ngOnInit() {
  }
  validate(){
    this.error=false;
    this.service.findUser(this.userlogname).subscribe(value=>this.userlogin=value);
    if(this.userlogin.userlogname==this.userlogname && this.userlogin.userlogemail==this.userlogemail 
      && this.userlogin.userpassword==this.userpassword && this.userlogin.role.id==1){
    
  this.router.navigate(['user-page',this.userlogname]);
  this.invalidLogin = false;
    }
    else if(this.userlogin.userlogname==this.userlogname && this.userlogin.userlogemail==this.userlogemail 
      && this.userlogin.userpassword==this.userpassword 
      && this.userlogin.role.id==2){
    
        this.router.navigate(['mentor-page',this.userlogname]);
        this.invalidLogin = false;
          }
          else  if(this.userlogin.userlogname==this.userlogname && this.userlogin.userlogemail==this.userlogemail 
            && this.userlogin.userpassword==this.userpassword 
            && this.userlogin.role.id==3){
    
            this.router.navigate(['admin-page',this.userlogname]);
            this.invalidLogin = false;
              }
          
else{
  this.invalidLogin=true;
}
  }
}
