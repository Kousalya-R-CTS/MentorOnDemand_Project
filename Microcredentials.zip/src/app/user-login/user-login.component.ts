import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import {CourseService} from '../course.service';
import { UserMain } from 'UserMain';
import { UserD } from 'UserD';
import { Role } from 'Role';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  username: string;
  useremail: string;
  password: string;
  confirmpassword: string;
  userMain:UserMain=new UserMain();
 userregister:UserD = new UserD();
role:Role=new Role();
private id=1;
private rolename="user";
  constructor(private route: Router, private service: CourseService) { }

  ngOnInit() {
  }
saveuserDetails() {
    this.userMain.username = this.username;
    this.userMain.password = this.password;
    this.userMain.useremail = this.useremail;
    this.userMain.confirmpassword = this.confirmpassword;
    this.role.id=this.id;
  this.role.role=this.rolename;
  this.userregister.role=this.role;
  this.userregister.userlogname = this.username;
  this.userregister.userlogemail = this.useremail;
  this.userregister.userpassword = this.password;
    if(this.username == null) {
      alert('Enter valid username');
      return false;
    }
    if (this.useremail == null) {
      alert('Enter valid mail id');
      return false;
      }
    if (this.password == null) {
       alert('Enter valid password');
       return false;
      }
    if (this.password.length < 8) {
        alert('Enter password with a length of 8 characters');
        return false;
      }
    if (this.password !== this.confirmpassword) {
        alert('Enter the both the password correctly');
        return false;
      }

    if ((this.username.length != null ) && (this.useremail.length != null) && (this.password.length >= 8) && (this.password == this.confirmpassword)) {
      this.service.createUser(this.userMain)
      .subscribe(data => console.log(data), error => console.log(error));

      this.service.createUserRegister(this.userregister)
      .subscribe(data => console.log(data), error => console.log(error));
      this.route.navigate(['admin-login']);
      return true;
      }
  }
}
