import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { UserPageComponent } from './user-page/user-page.component';
import { MentorPageComponent } from './mentor-page/mentor-page.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';

const routes: Routes = [
  {path: '', component:  HomePageComponent},
  {path: 'user-login', component: UserLoginComponent},
  {path: 'mentor-login', component: MentorLoginComponent},
  {path: 'admin-login', component: AdminLoginComponent},
  {path: 'user-page/:userlogname', component: UserPageComponent},
  {path: 'mentor-page/:userlogname', component: MentorPageComponent},
  {path: 'admin-page/:userlogname', component: AdminPageComponent},
  {path: 'mentor-profile', component: MentorProfileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
