import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-mentor-page',
  templateUrl: './mentor-page.component.html',
  styleUrls: ['./mentor-page.component.css']
})
export class MentorPageComponent implements OnInit {
  mentorsearch: string;
  userlogname: string;
  searchmt: string;

  private search = [];
private current = [];
private complete = [];
  disp = false;
  disp1 = false;
  disp2 = false;
  disp3 = false;
  disp4 = false;
  skill1: string;
  skill2: string;
  mname1: any;
  skill11: any;
  skill12: any;
  aCourse:string;
  constructor(private service: CourseService,private router:ActivatedRoute ) { }
    ngOnInit() {
      this.userlogname=this.router.snapshot.paramMap.get('userlogname');
    }
    message() {
      this.disp = false;
      this.disp1 = false;
      this.disp2 = false;
       this.disp3 = false;
      this.disp4 = true;
    }
  validatemt() {
    if ((this.aCourse === 'java' || this.aCourse=== '.net' || this.aCourse === 'angular' || this.aCourse === 'bootstrap')) {
  this.searchmt = this.aCourse;
  this.disp = true;
  this.disp1 = false;
  this.disp2 = false;
  this.disp3 = false;
  this.disp4 = false;
  
  this.service.searchtech(this.aCourse).subscribe(data => this.search = data as string[]);
  this.aCourse = '';
} else {
    this.mentorsearch = '';
  }
  }
  currentmt() {
    this.disp = false;
    this.disp1 = false;
    this.disp2 = true;
    this.disp3 = false;
    this.disp4 = false;
    this.service.getmentorcurrent(this.userlogname).subscribe(data => this.current = data as string[]);
  }
  completemt() {
    this.disp = false;
    this.disp1 = false;
    this.disp2 = false;
    this.disp3 = true;
    this.disp4 = false;
    this.service.getmentorcomplete(this.userlogname).subscribe(data => this.complete = data as string[]);
  }
  editskill() {
    this.disp = false;
    this.disp1 = true;
    this.disp2 = false;
    this.disp3 = false;
    this.disp4 = false;
  }

}
