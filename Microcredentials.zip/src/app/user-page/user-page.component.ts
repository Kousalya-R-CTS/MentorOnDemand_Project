import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-user-page',
  templateUrl: './user-page.component.html',
  styleUrls: ['./user-page.component.css']
})
export class UserPageComponent implements OnInit {
  usersearch: string;
  searchus: string;
  username: string;
  aCourse:string;
  private home = [];
  private showcourse = [];
  private currentuser = [];
  private completeuser = []; 
  disp = false;
  disp1 = false;
  disp2 = false;
  disp3 = false;
  constructor(private service: CourseService,private router:ActivatedRoute) { }
    ngOnInit() {
      this.username=this.router.snapshot.paramMap.get('userlogname');
    }
  courseDisp() {
  if ((this.aCourse === 'java' || this.aCourse=== '.net' || this.aCourse === 'angular' || this.aCourse === 'bootstrap')) {
  this.searchus = this.aCourse;
  this.disp = true;
  this.disp1 = false;
  this.disp2 = false;
  this.disp3 = false;
  this.service.searchtech(this.aCourse).subscribe(value => this.showcourse = value as string[]);
  this.aCourse = '';
} else {
    this.aCourse = '';
  }
  }
  allcourseus() {
    this.disp = false;
    this.disp1 = true;
    this.disp2 = false;
    this.disp3 = false;
    this.service.getallcourse().subscribe(data => this.showcourse = data as string[]);

  }
  currentus() {
    this.disp = false;
    this.disp1 = false;
    this.disp2 = true;
    this.disp3 = false;
    this.service.getusercurrent(this.username).subscribe(data => this.currentuser = data as string[]);
  }
  completeus() {
    this.disp = false;
    this.disp1 = false;
    this.disp2 = false;
    this.disp3 = true;
    this.service.getusercomplete(this.username).subscribe(data => this.completeuser = data as string[]);
  }
  }
