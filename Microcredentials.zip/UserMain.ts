export class UserMain {
    username:string;
    password:string;
    confirmpassword:string;
    useremail:string;
}