import { Role } from 'Role';

export class UserD {
  userlogname: String ;
  userpassword:String ;
	userlogemail:String ;
	role :Role;
}