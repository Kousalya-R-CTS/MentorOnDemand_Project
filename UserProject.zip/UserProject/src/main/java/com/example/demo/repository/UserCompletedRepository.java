package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.UserCompletedCourse;
import com.example.demo.model.UserD;

@Repository
public interface UserCompletedRepository extends JpaRepository<UserCompletedCourse, Integer>{

	public List<UserCompletedCourse> findByUserlogname(UserD u);

}
