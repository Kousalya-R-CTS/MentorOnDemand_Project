package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserAllCourses {
	
	@Id
	private int uaid;
	
	private String aCourse;
	private String aMentorName;
	private int aExperience;
	private String aDuration;
	private long aFees;
	public int getUaid() {
		return uaid;
	}
	public void setUaid(int uaid) {
		this.uaid = uaid;
	}
	public String getaMentorName() {
		return aMentorName;
	}
	public void setaMentorName(String aMentorName) {
		this.aMentorName = aMentorName;
	}
	public int getaExperience() {
		return aExperience;
	}
	public void setaExperience(int aExperience) {
		this.aExperience = aExperience;
	}
	public String getaCourse() {
		return aCourse;
	}
	public void setaCourse(String aCourse) {
		this.aCourse = aCourse;
	}
	public String getaDuration() {
		return aDuration;
	}
	public void setaDuration(String aDuration) {
		this.aDuration = aDuration;
	}
	public long getaFees() {
		return aFees;
	}
	public void setaFees(long aFees) {
		this.aFees = aFees;
	}
	
}
