package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Role;
import com.example.demo.model.UserAllCourses;
import com.example.demo.model.UserCompletedCourse;
import com.example.demo.model.UserCurrentCourse;
import com.example.demo.model.UserD;
import com.example.demo.model.UserMain;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserAllCoursesRepository;
import com.example.demo.repository.UserCompletedRepository;
import com.example.demo.repository.UserCurrentRepository;
import com.example.demo.repository.UserDetailRepository;
import com.example.demo.repository.UserMainRepository;

@Service
public class UserService {

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private UserDetailRepository userDetailRepository;

	@Autowired
	private UserCompletedRepository userCompletedRepository;

	@Autowired
	private UserCurrentRepository userCurrentRepository;

	@Autowired
	private UserAllCoursesRepository userAllCoursesRepository;
	
	@Autowired
	private UserMainRepository userMainRepository;

	public String saveRole(Role r) {
		roleRepository.save(r);
		return "User Role Saved";
	}

	public Iterable<Role> showallroles() {
		return roleRepository.findAll();
	}

	public Role findrole(int rid) {
		return roleRepository.findById(rid);
	}

	public String adduser(UserD u) {

		int uid = 1;
		Role r = roleRepository.findById(uid);
		u.setRole(r);

		userDetailRepository.save(u);
		return "Log in user Details Saved";
	}

	public List<UserD> findAllUser() {
		return userDetailRepository.findAll();
	}

	public UserD findUser(String userlogname) {
		return userDetailRepository.findByUserlogname(userlogname);
	}

	public List<UserCompletedCourse> findcomplete(String userlogname) {

		UserD u = userDetailRepository.findByUserlogname(userlogname);
		return userCompletedRepository.findByUserlogname(u);
	}

	public List<UserCompletedCourse> findAllComplete() {
		return userCompletedRepository.findAll();
	}

	public List<UserCurrentCourse> findcurrent(String userlogname) {

		UserD u = userDetailRepository.findByUserlogname(userlogname);
		return userCurrentRepository.findByUserlogname(u);
	}

	public List<UserCurrentCourse> findAllCurrent() {
		return userCurrentRepository.findAll();
	}

	public List<UserAllCourses> findAllCourse() {
		return userAllCoursesRepository.findAll();
	}

	public List<UserAllCourses> findtech(String tech) {
	return userAllCoursesRepository.findByaCourse(tech);
	}

	public String saveuserDetails(UserMain um) {
		userMainRepository.save(um);
		return "Sign Up user Details Saved";
	}

	public List<UserMain> showalluser() {
		
		return userMainRepository.findAll();
	}

	public List<UserMain> showuserdetail(String username) {
		
		return userMainRepository.findByUsername(username);
	}

}
