package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserCurrentCourse {
	
	@Id
	private int uccid;
	
	private String uCourse;
	private String uMentorName;
	private String uDuration;
	private long uFees;
	private String uPercent;
	private String uRem;
	
	@ManyToOne()
	@JoinColumn(name="userlogname")
	private UserD userlogname;

	public UserD getUserlogname() {
		return userlogname;
	}

	public void setUserlogname(UserD userlogname) {
		this.userlogname = userlogname;
	}

	public int getUccid() {
		return uccid;
	}

	public void setUccid(int uccid) {
		this.uccid = uccid;
	}

	public String getuCourse() {
		return uCourse;
	}

	public void setuCourse(String uCourse) {
		this.uCourse = uCourse;
	}

	public String getuMentorName() {
		return uMentorName;
	}

	public void setuMentorName(String uMentorName) {
		this.uMentorName = uMentorName;
	}

	public String getuDuration() {
		return uDuration;
	}

	public void setuDuration(String uDuration) {
		this.uDuration = uDuration;
	}

	public long getuFees() {
		return uFees;
	}

	public void setuFees(long uFees) {
		this.uFees = uFees;
	}

	public String getuPercent() {
		return uPercent;
	}

	public void setuPercent(String uPercent) {
		this.uPercent = uPercent;
	}


	public String getuRem() {
		return uRem;
	}

	public void setuRem(String uRem) {
		this.uRem = uRem;
	}
	
}
