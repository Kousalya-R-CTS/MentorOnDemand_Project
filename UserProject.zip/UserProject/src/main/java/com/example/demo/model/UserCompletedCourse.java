package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserCompletedCourse {
	
	@Id
	private int ucid;
	
	private String course;
	private String mentorName;
	private String duration;
	private long fees;
	private String percent;
	
	@ManyToOne()
	@JoinColumn(name="userlogname")
	private UserD userlogname;

	public UserD getUserlogname() {
		return userlogname;
	}

	public void setUserlogname(UserD userlogname) {
		this.userlogname = userlogname;
	}

	public int getUcid() {
		return ucid;
	}

	public void setUcid(int ucid) {
		this.ucid = ucid;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getMentorName() {
		return mentorName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public long getFees() {
		return fees;
	}

	public void setFees(long fees) {
		this.fees = fees;
	}

	public String getPercent() {
		return percent;
	}

	public void setPercent(String percent) {
		this.percent = percent;
	}

	
	

}
