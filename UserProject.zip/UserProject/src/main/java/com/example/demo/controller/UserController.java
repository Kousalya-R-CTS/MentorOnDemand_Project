package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Role;
import com.example.demo.model.UserAllCourses;
import com.example.demo.model.UserCompletedCourse;
import com.example.demo.model.UserCurrentCourse;
import com.example.demo.model.UserD;
import com.example.demo.model.UserMain;
import com.example.demo.service.UserService;

@Controller
@RequestMapping(path="/user")
@CrossOrigin("http://localhost:4200")  
public class UserController {
	
	@Autowired
	private UserService userService;

	
	@PostMapping(path="/role")
	public @ResponseBody String role(@RequestBody Role r) {
		return userService.saveRole(r);
	}
	
	@GetMapping(path="/identity")
	public @ResponseBody Iterable<Role> showall() {
		return userService.showallroles();
	}
	
	@GetMapping(path="/identity/{id}")
	public @ResponseBody Role showRole(@PathVariable("id") int rid) {
		return userService.findrole(rid);
	}
	
	@PostMapping(path="/add")
	public @ResponseBody String createUserRegister(@RequestBody UserD u) {
		return userService.adduser(u);
	}

	@GetMapping(path="/all")
	public @ResponseBody List<UserD> showUser() {
	return userService.findAllUser(); 
	}
	
	@GetMapping(path="/all/{userlogname}")
	public @ResponseBody UserD findUser(@PathVariable("userlogname") String username) {
		return userService.findUser(username);
	}
	
	@GetMapping(path="/completed/{userlogname}")
	public @ResponseBody List<UserCompletedCourse> showCompleted(@PathVariable("userlogname") String username) {
		return userService.findcomplete(username);
	}
	
	@GetMapping(path="/completed/all")
	public @ResponseBody List<UserCompletedCourse> showAll() {
		return userService.findAllComplete();
	}
	
	@GetMapping(path="/current/{userlogname}")
	public @ResponseBody List<UserCurrentCourse> showCurrent(@PathVariable("userlogname") String username) {
		return userService.findcurrent(username);
	}
	
	@GetMapping(path="/current/all")
	public @ResponseBody List<UserCurrentCourse> showCurrentAll() {
		return userService.findAllCurrent();
	}
	
	@GetMapping(path="/allcourses")
	public @ResponseBody List<UserAllCourses> showAllCourse() {
		return userService.findAllCourse();
	}
	
	@GetMapping(path="/search/{aCourse}")
	public @ResponseBody List<UserAllCourses> searchtech(@PathVariable("aCourse") String tech) {
		return userService.findtech(tech);
	}
	
	@PostMapping(path="/saveuser")
	public @ResponseBody String createUser(@RequestBody UserMain um) {
		return userService.saveuserDetails(um);
	}
	
	@GetMapping(path="/alluser")
	public @ResponseBody List<UserMain> show() {
		return userService.showalluser();
	}
	
	@GetMapping(path="/show/{username}")
	public @ResponseBody List<UserMain> showUser(@PathVariable("username") String username) {
		return userService.showuserdetail(username);
	}
}